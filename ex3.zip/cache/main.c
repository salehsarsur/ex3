/* 213128713 Saleh Sarsur */

#include <stdio.h>
#include <malloc.h>

typedef unsigned char uchar;
typedef struct cache_line_s {
    uchar valid;
    uchar frequency;
    long int tag;
    uchar *block;
} cache_line_t;
typedef struct cache_s {
    uchar s;
    uchar t;
    uchar b;
    uchar E;
    cache_line_t **cache;
} cache_t;

cache_t initialize_cache(uchar s, uchar t, uchar b, uchar E){

    cache_t cache;
    cache.s = s;
    cache.t = t;
    cache.b = b;
    cache.E = E;
    int S = 1 << s;
    int B = 1 << b;
    cache_line_t **cacheArray = malloc(sizeof(cache_line_t) * S * E);

    for (int i = 0; i < S; ++i) {
        cacheArray[i] = malloc(sizeof(cache_line_t));
        for (int j = 0; j < E; j++) {
            cacheArray[i][j].valid = 0;
            cacheArray[i][j].frequency = 0;
            cacheArray[i][j].tag = 0;
            cacheArray[i][j].block = malloc(sizeof(uchar) * B);
            for (int k = 0; k < B; k++) {
                cacheArray[i][j].block[k] = 0;
            }
        }
    }
    cache.cache = cacheArray;
    return cache;
}

uchar read_byte(cache_t cache, uchar* start, long int off){
    int set = (off >> cache.b) % (1 << cache.s);
    int tag = (off >> (cache.s + cache.b)) % (1 << cache.t);
    int block = off % (1 << cache.b);
    int start_size = sizeof(start) / sizeof(uchar);
    int B = 1 << cache.b;

    if(off >= start_size)
        return start[off];

    // that loop checks if the data is already there
    for (int i = 0; i < cache.E; ++i) {
        if (cache.cache[set][i].tag == tag) {
            if (cache.cache[set][i].block[block] == start[off]) {
                cache.cache[set][i].frequency += 1;
                return start[off];
            }
        }
    }

    // if not there so I check if there is a place to add him.
    for (int i = 0; i < cache.E; ++i) {
        if (cache.cache[set][i].valid == 0) {
            cache.cache[set][i].valid = 1;
            cache.cache[set][i].frequency = 1;
            cache.cache[set][i].tag = tag;
            for (int j = 0; j < B; ++j) {
                if (off + j + 1 > start_size) {
                    break;
                }
                cache.cache[set][i].block[j] = start[off + j];
            }
            return start[off];
        }
    }
    // if I reached there that means that the data isn't in the cache and cant even add it, cache it is full.
    // now I need to remove data that is the least frequency used, and replace it with new one.
    int lowest_frequency = cache.cache[set][0].frequency;
    int index_lowest_frequency = 0;
    for (int i = 0; i < cache.E; ++i) {
        if (lowest_frequency > cache.cache[set][i].frequency) {
            lowest_frequency = cache.cache[set][i].frequency;
            index_lowest_frequency = i;
        }
    }

    cache.cache[set][index_lowest_frequency].frequency += 1;
    cache.cache[set][index_lowest_frequency].tag = tag;
    for (int j = 0; j < B; ++j) {
        if (off + j + 1 > start_size) {
            break;
        }
        cache.cache[set][index_lowest_frequency].block[j] = start[off + j];
    }
    return start[off];

}

void write_byte(cache_t cache, uchar* start, long int off, uchar new){
    start[off] = new;
    read_byte(cache,start,off);
}

void print_cache(cache_t cache){
        int S=1<<cache.s;
        int B=1<<cache.b;

        for(int i=0;i<S;i++){
            printf("Set %d\n",i);
            for(int j=0;j<cache.E;j++){
                printf("%1d %d 0x%0*lx",cache.cache[i][j].valid,
                         cache.cache[i][j].frequency,cache.t,cache.cache[i][j].tag);
                for(int k=0;k<B;k++){
                     printf(" %02x",cache.cache[i][j].block[k]);
                    }
                puts("");
                }
            }
        }

int main(){
    int n;
    printf("Size of data: ");
    scanf("%d",&n);
    uchar* mem = malloc(n);
    printf("Input data>>");
    for(int i=0;i<n;i++)
        scanf("%hhd",mem + i);

    int s,t,b,E;
    printf("s t b E: ");
    scanf("%d %d %d %d",&s,&t,&b,&E);
    cache_t cache=initialize_cache(s,t,b,E);

    while(1){
        scanf("%d",&n);
        if(n<0)break;
        read_byte(cache,mem,n);
        }

    puts("");
    print_cache(cache);

    free(mem);
}