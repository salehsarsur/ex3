/* 213128713 Saleh Sarsur */
#include "fmm.h"

void fmm(int n, int* m1, int* m2, int* result) {
    int* col1 = malloc(n * sizeof(int));
    int* col2 = malloc(n * sizeof(int));
    int s = 0;int t = 0;
    long int square = n * n;

    for (int j = 0; j < n; j+=2) {
        for (int k = 0; k < n; k+=2){
            *col1++ = *m2++;*col2++ = *m2;
            m2 += n - 1;
            *col1++ = *m2++;*col2++ = *m2;
            m2 += n - 1;
        }
        col1 -= n;col2 -= n;
        m2 -= square;
        for (int i = 0; i < n; i++) {
            for (int k = 0; k < n; k+=2) {
                t += *m1 * *col2++;s += *m1++ * *col1++;
                t += *m1 * *col2++;s += *m1++ * *col1++;
            }
            col1 -= n;col2 -= n;
            *result++ = s;
            *result = t;
            result += n - 1;
            s = 0;t = 0;
        }
        result -= square;result += 2;
        m1 -= square;m2 += 2;
    }
}
